<?php

namespace App\Controllers;
use App\Models\ObjectivesModel;
use App\Models\ActivitiesModel;


class ActivitiesController extends BaseController
{

	public function index($id = false)
	{   
        $ActivitiesModel = new ActivitiesModel();

        if(!empty($id)){
            $data['activities'] = $ActivitiesModel->activities_by_objective_id($id);

            $ObjectivesModel = new ObjectivesModel();
            $project = $ObjectivesModel->where('id', $id)->first();
            $data['actv_name'] = $project['objective_name'];
            $data['actv_id'] = $id;

        }else{
            $data['actv_name'] = '';
            $data['actv_id'] = '';
            $data['activities'] = $ActivitiesModel->activities_with_objectives_info();
        }
        
		return view('activities/data', $data);
	}

    // add activity form
	public function create($id)
	{
        $ObjectivesModel = new ObjectivesModel();
        $data['obj_actv'] = $ObjectivesModel->where('id', $id)->first();

		return view('activities/create',$data);
	}

    // insert data
    public function store() {
        $ActivitiesModel = new ActivitiesModel();

        //created by user in session
        $user_id = 1; 
        $data = [
            'activity_name'         => $this->request->getVar('activity_name'),
            'activity_description'  => $this->request->getVar('activity_description'),
            'objective_id'          => $this->request->getVar('objective_id'),
            'created_by'            => $user_id,
        ];
        $ActivitiesModel->insert($data);
        return $this->response->redirect(site_url('activity-list'));
    }

    // show single activity
    public function singleActivity($id = null){
        $ActivitiesModel = new ActivitiesModel();
        $ObjectivesModel   = new ObjectivesModel();

        $data['objective'] = $ActivitiesModel->where('id', $id)->first();
        $data['objective_obj'] = $ObjectivesModel->where('id', $id)->first();

        return view('activities/edit', $data);
    }

    // update activity data
    public function update(){
        $ActivitiesModel = new ActivitiesModel();
        $id = $this->request->getVar('id');

        //updated by user in session
        $user_id = 1; 
        $data = [
            'activity_name'         => $this->request->getVar('activity_name'),
            'activity_description'  => $this->request->getVar('activity_description'),
            'objective_id'          => $this->request->getVar('objective_id'),
            'created_by'            => $user_id,
        ];
        $ActivitiesModel->update($id, $data);
        return $this->response->redirect(site_url('activity-list'));
    }
 
    // delete activity
    public function delete($id = null){
        $ActivitiesModel = new ActivitiesModel();
        $data['objective'] = $ActivitiesModel->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('activity-list'));
    }    
	//--------------------------------------------------------------------

}
