<?php

namespace App\Controllers;

class Calendar extends BaseController
{
	public function index()
	{
		return view('pages_adminLTE/calendar');
	}

	public function calendar()
	{
		return view('pages_adminLTE/calendar');
	}

	//--------------------------------------------------------------------

}
