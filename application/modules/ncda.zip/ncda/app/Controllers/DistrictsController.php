<?php

namespace App\Controllers;
use App\Models\DistrictsModel;

class DistrictsController extends BaseController
{
	public function index()
	{
        $DistrictsModel = new DistrictsModel();
        $data['districts'] = $DistrictsModel->orderBy('region', 'ASC')->findAll();
		return view('districts/data', $data);
	}

    // add district form
	public function create()
	{
		return view('districts/create');
	}

    // insert data
    public function store() {
        $DistrictsModel = new DistrictsModel();
        $data = [
            'district_name' => $this->request->getVar('district_name'),
            'region'  => $this->request->getVar('region'),
            'notes'  => $this->request->getVar('notes'),
            'active'  => $this->request->getVar('active'),
        ];
        $DistrictsModel->insert($data);
        return $this->response->redirect(site_url('district-list'));
    }

    // show single district
    public function singleDistrict($id = null){
        $DistrictsModel = new DistrictsModel();
        $data['dt_obj'] = $DistrictsModel->where('id', $id)->first();
        return view('districts/edit', $data);
    }

    // update district data
    public function update(){
        $DistrictsModel = new DistrictsModel();
        $id = $this->request->getVar('id');
        $data = [
            'district_name' => $this->request->getVar('district_name'),
            'region'  => $this->request->getVar('region'),
            'notes'  => $this->request->getVar('notes'),
            'active'  => $this->request->getVar('active'),
        ];
        $DistrictsModel->update($id, $data);
        return $this->response->redirect(site_url('district-list'));
    }
 
    // delete district
    public function delete($id = null){
        $DistrictsModel = new DistrictsModel();
        $data['district'] = $DistrictsModel->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('district-list'));
    }    
	//--------------------------------------------------------------------

}
