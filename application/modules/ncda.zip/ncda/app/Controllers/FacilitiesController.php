<?php

namespace App\Controllers;
use App\Models\DistrictsModel;
use App\Models\FacilitiesModel;

class FacilitiesController extends BaseController
{
	public function index()
	{
        $DistrictsModel     = new DistrictsModel();
        $FacilitiesModel    = new FacilitiesModel();
        $data['districts']  = $DistrictsModel->orderBy('region', 'ASC')->findAll();
        $data['facilities'] = $FacilitiesModel->orderBy('id', 'ASC')->findAll();
		return view('facilities/data', $data);
	}

    // add facilities form
	public function create()
	{
		return view('facilities/create');
	}

    // insert data
    public function store() {
        $FacilitiesModel = new FacilitiesModel();
        $data = [
            'district_name' => $this->request->getVar('district_name'),
            'region'        => $this->request->getVar('region'),
            'notes'         => $this->request->getVar('notes'),
            'active'        => $this->request->getVar('active'),
        ];
        $FacilitiesModel->insert($data);
        return $this->response->redirect(site_url('facility-list'));
    }

    // show single facility
    public function singleDistrict($id = null){
        $FacilitiesModel = new FacilitiesModel();
        $data['dt_obj']  = $FacilitiesModel->where('id', $id)->first();
        return view('facilities/edit', $data);
    }

    // update facility data
    public function update(){
        $FacilitiesModel = new FacilitiesModel();
        $id = $this->request->getVar('id');
        $data = [
            'district_name' => $this->request->getVar('district_name'),
            'region'  => $this->request->getVar('region'),
            'notes'   => $this->request->getVar('notes'),
            'active'  => $this->request->getVar('active'),
        ];
        $FacilitiesModel->update($id, $data);
        return $this->response->redirect(site_url('facility-list'));
    }
 
    // delete facility
    public function delete($id = null){
        $FacilitiesModel  = new FacilitiesModel();
        $data['facility'] = $FacilitiesModel->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('facility-list'));
    }    
	//--------------------------------------------------------------------

}
