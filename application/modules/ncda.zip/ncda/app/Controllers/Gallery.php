<?php

namespace App\Controllers;

class Gallery extends BaseController
{
	public function index()
	{
		return view('pages_adminLTE/gallery');
	}

	public function gallery()
	{
		return view('pages_adminLTE/gallery');
	}

	//--------------------------------------------------------------------

}
