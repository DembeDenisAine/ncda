<?php

namespace App\Controllers;

class Iframe extends BaseController
{
	public function index()
	{
		return view('pages_adminLTE/iframe');
	}

	public function iframe()
	{
		return view('pages_adminLTE/iframe');
	}

	//--------------------------------------------------------------------

}
