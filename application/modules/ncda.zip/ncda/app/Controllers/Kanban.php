<?php

namespace App\Controllers;

class Kanban extends BaseController
{
	public function index()
	{
		return view('pages_adminLTE/kanban');
	}

	public function kanban()
	{
		return view('pages_adminLTE/kanban');
	}

//--------------------------------------------------------------------

}
