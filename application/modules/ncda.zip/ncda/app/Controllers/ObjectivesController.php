<?php

namespace App\Controllers;
use App\Models\ProjectsModel;
use App\Models\ObjectivesModel;

class ObjectivesController extends BaseController
{

	public function index($id = false)
	{   
        $ObjectivesModel = new ObjectivesModel();

        if(!empty($id)){
            $data['objectives'] = $ObjectivesModel->objectives_by_project_id($id);

            $ProjectsModel = new ProjectsModel();
            $project = $ProjectsModel->where('id', $id)->first();
            $data['proj_name'] = $project['project_name'];
            $data['proj_id'] = $id;

        }else{
            $data['proj_name'] = '';
            $data['proj_id'] = '';
            $data['objectives'] = $ObjectivesModel->objectives_with_project_info();
        }
        
		return view('objectives/data', $data);
	}

    // add objective form
	public function create($id)
	{
        $ProjectsModel = new ProjectsModel();
        $data['project_obj'] = $ProjectsModel->where('id', $id)->first();

		return view('objectives/create',$data);
	}

    // insert data
    public function store() {
        $ObjectivesModel = new ObjectivesModel();

        //created by user in session
        $user_id = 1; 
        $data = [
            'objective_name'         => $this->request->getVar('objective_name'),
            'objective_description'  => $this->request->getVar('objective_description'),
            'project_id'             => $this->request->getVar('project_id'),
            'created_by'             => $user_id,
        ];
        $ObjectivesModel->insert($data);
        return $this->response->redirect(site_url('objective-list'));
    }

    // show single objective
    public function singleProject($id = null){
        $ObjectivesModel = new ObjectivesModel();
        $ProjectsModel   = new ProjectsModel();

        $data['objective'] = $ObjectivesModel->where('id', $id)->first();
        $data['project_obj'] = $ProjectsModel->where('id', $id)->first();

        return view('objectives/edit', $data);
    }

    // update objective data
    public function update(){
        $ObjectivesModel = new ObjectivesModel();
        $id = $this->request->getVar('id');

        
        
        //updated by user in session
        $user_id = 1; 
        $data = [
            'objective_name'         => $this->request->getVar('objective_name'),
            'objective_description'  => $this->request->getVar('objective_description'),
            'project_id'             => $this->request->getVar('project_id'),
            'created_by'             => $user_id,
        ];
        $ObjectivesModel->update($id, $data);
        return $this->response->redirect(site_url('objective-list'));
    }
 
    // delete objective
    public function delete($id = null){
        $ObjectivesModel = new ObjectivesModel();
        $data['objective'] = $ObjectivesModel->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('objective-list'));
    }    
	//--------------------------------------------------------------------

}
