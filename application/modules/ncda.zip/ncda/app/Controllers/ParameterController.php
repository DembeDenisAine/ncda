<?php

namespace App\Controllers;
use App\Models\ActivitiesModel;
use App\Models\ParameterModel;

class ParameterController extends BaseController
{

	public function index($id = false)
	{   
        $ParameterModel = new ParameterModel();

        if(!empty($id)){
            $data['parameters'] = $ParameterModel->parameters_by_activity_id($id);

            $ActivitiesModel = new ActivitiesModel();
            $project = $ActivitiesModel->where('id', $id)->first();
            $data['actv_name'] = $project['activity_name'];
            $data['actv_id'] = $id;

        }else{
            $data['actv_name'] = '';
            $data['actv_id'] = '';
            $data['parameters'] = $ParameterModel->parameters_with_activities_info();
        }
        
		return view('parameters/data', $data);
	}

    // add parameters form
	public function create($id)
	{
        $ActivitiesModel = new ActivitiesModel();
        $data['obj_actv'] = $ActivitiesModel->where('id', $id)->first();

		return view('parameters/create',$data);
	}

    // insert data
    public function store() {
        $ParameterModel = new ParameterModel();

        //created by user in session
        $user_id = 1; 
        $data = [
            'parameter_name'         => $this->request->getVar('parameter_name'),
            'parameter_description'  => $this->request->getVar('parameter_description'),
            'activity_id'            => $this->request->getVar('activity_id'),
            'created_by'             => $user_id,
        ];
        $ParameterModel->insert($data);
        return $this->response->redirect(site_url('parameter-list'));
    }

    // show single parameter
    public function singleActivity($id = null){
        $ParameterModel = new ParameterModel();
        $ActivitiesModel   = new ActivitiesModel();

        $data['objective'] = $ParameterModel->where('id', $id)->first();
        $data['objective_obj'] = $ActivitiesModel->where('id', $id)->first();

        return view('parameters/edit', $data);
    }

    // update parameter data
    public function update(){
        $ParameterModel = new ParameterModel();
        $id = $this->request->getVar('id');

        //updated by user in session
        $user_id = 1; 
        $data = [
            'parameter_name'         => $this->request->getVar('parameter_name'),
            'parameter_description'  => $this->request->getVar('parameter_description'),
            'activity_id'            => $this->request->getVar('activity_id'),
            'created_by'             => $user_id,
        ];
        $ParameterModel->update($id, $data);
        return $this->response->redirect(site_url('parameter-list'));
    }
 
    // delete parameter
    public function delete($id = null){
        $ParameterModel = new ParameterModel();
        $data['objective'] = $ParameterModel->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('parameter-list'));
    }    
	//--------------------------------------------------------------------

}

