<?php

namespace App\Controllers;
use App\Models\ProjectsModel;

class ProjectsController extends BaseController
{
	public function index()
	{
        $ProjectsModel = new ProjectsModel();
        $data['projects'] = $ProjectsModel->orderBy('id', 'DESC')->findAll();
		return view('projects/data', $data);
	}

    // add project form
	public function create()
	{
		return view('projects/create');
	}

    // insert data
    public function store() {
        $ProjectsModel = new ProjectsModel();

        $start_date = $this->request->getVar('start_date');
        $end_date = $this->request->getVar('end_date');

        $diff = strtotime($start_date) - strtotime($end_date);
        $duration = ceil(abs($diff / 86400)).' days';

        $data = [
            'project_name'  => $this->request->getVar('project_name'),
            'start_date'    => $start_date,
            'end_date'      => $end_date,
            'duration'      => $duration,
            'project_description'  => $this->request->getVar('project_description'),
        ];
        $ProjectsModel->insert($data);
        return $this->response->redirect(site_url('project-list'));
    }

    // show single project
    public function singleProject($id = null){
        $ProjectsModel = new ProjectsModel();
        $data['project_obj'] = $ProjectsModel->where('id', $id)->first();
        return view('projects/edit', $data);
    }

    // update project data
    public function update(){
        $ProjectsModel = new ProjectsModel();
        $id = $this->request->getVar('id');
        
        $start_date = $this->request->getVar('start_date');
        $end_date = $this->request->getVar('end_date');

        $diff = strtotime($start_date) - strtotime($end_date);
        $duration = ceil(abs($diff / 86400)).' days';

        $data = [
            'project_name'  => $this->request->getVar('project_name'),
            'start_date'    => $start_date,
            'end_date'      => $end_date,
            'duration'      => $duration,
            'project_description'  => $this->request->getVar('project_description'),
        ];
        $ProjectsModel->update($id, $data);
        return $this->response->redirect(site_url('project-list'));
    }
 
    // delete project
    public function delete($id = null){
        $ProjectsModel = new ProjectsModel();
        $data['project'] = $ProjectsModel->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('project-list'));
    }    
	//--------------------------------------------------------------------

}
