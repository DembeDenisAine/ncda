<?php

namespace App\Controllers;

class Starter extends BaseController
{
	public function index()
	{
		return view('pages_adminLTE/starter');
	}

	public function starter()
	{
		return view('pages_adminLTE/starter');
	}
//--------------------------------------------------------------------

}
