<?php

namespace App\Controllers;

class Widgets extends BaseController
{
	public function index()
	{
		return view('pages_adminLTE/widgets');
	}

	public function widgets()
	{
		return view('pages_adminLTE/widgets');
	}

//--------------------------------------------------------------------

}
